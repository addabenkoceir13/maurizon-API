<?php $__env->startSection('title', __('Users')); ?>

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-3">
  <span class="text-muted fw-light"><?php echo e(__('Users')); ?> /</span> <?php echo e(__('Browse users')); ?>

</h4>

<!-- Basic Bootstrap Table -->
<div class="card">
  <h5 class="card-header"><?php echo e(__('Users table')); ?></h5>
  <div class="table-responsive text-nowrap">
    <table class="table" id="laravel_datatable">
      <thead>
        <tr>
          <th>#</th>
          <th><?php echo e(__('Name')); ?></th>
          <th><?php echo e(__('Phone')); ?></th>
          <th><?php echo e(__('Email')); ?></th>
          <th><?php echo e(__('Status')); ?></th>
          <th><?php echo e(__('Created at')); ?></th>
          <th><?php echo e(__('Actions')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script>
  $(document).ready(function(){
    load_data();
    function load_data() {
        //$.fn.dataTable.moment( 'YYYY-M-D' );
        var table = $('#laravel_datatable').DataTable({

            responsive: true,
            processing: true,
            serverSide: true,

            ajax: {
                url: "<?php echo e(url('user/list')); ?>",
            },

            type: 'GET',

            columns: [

                {
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },

                {
                    data: 'name',
                    name: 'name'
                },

                {
                    data: 'phone',
                    name: 'phone'
                },


                {
                    data: 'phone',
                    name: 'phone'
                },


                {
                    data: 'status',
                    name: 'status',
                    render: function(data){
                          if(data == false){
                              return '<span class="badge bg-danger"><?php echo e(__("Inactive")); ?></span>';
                            }else{
                              return '<span class="badge bg-success"><?php echo e(__("Active")); ?></span>';
                            }
                          }
                },

                {
                    data: 'created_at',
                    name: 'created_at'
                },

                {
                    data: 'action',
                    name: 'action',
                    render:function(data){
                      return '<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu">'
                        +data+'</div></div>'
                    }
                }

            ]
        });
    }

    $(document.body).on('click', '.delete', function() {

      var user_id = $(this).attr('table_id');

      Swal.fire({
        title: "<?php echo e(__('Warning')); ?>",
        text: "<?php echo e(__('Are you sure?')); ?>",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: "<?php echo e(__('Yes')); ?>",
        cancelButtonText: "<?php echo e(__('No')); ?>"
      }).then((result) => {
        if (result.isConfirmed) {

          $.ajax({
            url: "<?php echo e(url('user/delete')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:{user_id : user_id},
            dataType : 'JSON',
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });


        }
      })
      });

      $(document.body).on('click', '.restore', function() {

      var user_id = $(this).attr('table_id');

      Swal.fire({
        title: "<?php echo e(__('Warning')); ?>",
        text: "<?php echo e(__('Are you sure?')); ?>",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: "<?php echo e(__('Yes')); ?>",
        cancelButtonText: "<?php echo e(__('No')); ?>"
      }).then((result) => {
        if (result.isConfirmed) {

          $.ajax({
            url: "<?php echo e(url('user/restore')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:{user_id : user_id},
            dataType : 'JSON',
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });


        }
      })
      });

  });



</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\njeek\resources\views/content/users/list.blade.php ENDPATH**/ ?>