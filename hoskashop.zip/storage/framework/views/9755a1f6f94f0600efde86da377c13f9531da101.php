<?php $__env->startSection('title', __('Ads')); ?>

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-3">
  <span class="text-muted fw-light"><?php echo e(__('Ads')); ?> /</span> <?php echo e(__('Browse ads')); ?>

  <button type="button" class="btn btn-primary" id="create" style="float:right"><?php echo e(__('Add ad')); ?></button>
</h4>

<!-- Basic Bootstrap Table -->
<div class="card">
  <h5 class="card-header"><?php echo e(__('Ads table')); ?></h5>
  <div class="table-responsive text-nowrap">
    <table class="table" id="laravel_datatable">
      <thead>
        <tr>
          <th>#</th>
          <th><?php echo e(__('Name')); ?></th>
          <th><?php echo e(__('Created at')); ?></th>
          <th><?php echo e(__('Actions')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>


<div class="modal fade" id="modal"  aria-hidden="true">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="fw-bold py-1 mb-1"><?php echo e(__('Add ad')); ?></h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="text" id="form_type" hidden />
        <input type="text" class="form-control" id="id" name="id" hidden/>
        <form class="form-horizontal" onsubmit="event.preventDefault()" action="#"
          enctype="multipart/form-data" id="form">
          <div class="card-body">
            <div class="d-flex align-items-start align-items-sm-center gap-4">
              <div hidden><img src="<?php echo e(asset('assets/img/icons/ad-not-found.jpg')); ?>"  alt="image" class="d-block rounded" height="120" width="500" id="old-image"/> </div>
              <img src="<?php echo e(asset('assets/img/icons/ad-not-found.jpg')); ?>" alt="image" class="d-block rounded" height="120" width="500" id="uploaded-image" />
            </div>
            <div class="button-wrapper" style="text-align: center;">
              <br>
              <label for="image" class="btn btn-primary" tabindex="0">
                <span class="d-none d-sm-block"><?php echo e(__('Upload new image')); ?></span>
                <i class="bx bx-upload d-block d-sm-none"></i>
                <input class="image-input" type="file" id="image" name="image" hidden accept="image/png, image/jpeg" />
              </label>
              <button type="button" class="btn btn-outline-secondary image-reset">
                <i class="bx bx-reset d-block d-sm-none"></i>
                <span class="d-none d-sm-block"><?php echo e(__('Reset')); ?></span>
              </button>
              <br>
              
            </div>
          </div>
          <hr class="my-0">
            <div class="mb-3">
              <label class="form-label" for="name"><?php echo e(__('Name')); ?></label>
              <input type="text" class="form-control" id="name" name="name"/>
            </div>

            <div class="mb-3">
              <label class="form-label" for="name"><?php echo e(__('URL')); ?></label>
              <input type="text" class="form-control" id="url" name="url"/>
            </div>


          <div class="mb-3" style="text-align: center">
            <button type="submit" id="submit" name="submit" class="btn btn-primary"><?php echo e(__('Send')); ?></button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
  $(document).ready(function(){
    load_data();
    function load_data() {
        //$.fn.dataTable.moment( 'YYYY-M-D' );
        var table = $('#laravel_datatable').DataTable({

            responsive: true,
            processing: true,
            serverSide: true,
            pageLength: 100,

            ajax: {
                url: "<?php echo e(url('ad/list')); ?>",
            },

            type: 'GET',

            columns: [

                {
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },

                {
                    data: 'name',
                    name: 'name'
                },

                {
                    data: 'created_at',
                    name: 'created_at'
                },


                {
                    data: 'action',
                    name: 'action',
                    render:function(data){
                      /* return '<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu">'
                        +data+'</div></div>' */
                        return '<span>'+data+'</span>';
                    }
                }

            ]
        });
    }

    $('#create').on('click', function() {
      document.getElementById('form').reset();
      document.getElementById('form_type').value = "create";
      document.getElementById('uploaded-image').src = "<?php echo e(asset('assets/img/icons/ad-not-found.jpg')); ?>" ;
      document.getElementById('old-image').src = "<?php echo e(asset('assets/img/icons/ad-not-found.jpg')); ?>" ;
      $("#modal").modal('show');
    });


    $(document.body).on('click', '.update', function() {
      document.getElementById('form').reset();
      document.getElementById('form_type').value = "update";
      var ad_id = $(this).attr('table_id');
      $("#id").val(ad_id);

      $.ajax({
          url: '<?php echo e(url('ad/update')); ?>',
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          type:'POST',
          data:{ad_id : ad_id},
          dataType : 'JSON',
          success:function(response){
              if(response.status==1){

                document.getElementById('name').value =  response.data.name;
                document.getElementById('url').value =  response.data.url;

                //console.log(response.data.image);

                var image = response.data.image == null ?
                "<?php echo e(asset('assets/img/icons/ad-not-found.jpg')); ?>" : response.data.image;

                document.getElementById('uploaded-image').src = image;
                document.getElementById('old-image').src = image;

                $("#modal").modal("show");
              }
            }
        });
    });

    $('#submit').on('click', function() {

      var formdata = new FormData($("#form")[0]);
       var formtype = document.getElementById('form_type').value;
       console.log(formtype);
       if(formtype == "create"){
        url = "<?php echo e(url('ad/create')); ?>";
       }

      if(formtype == "update"){
        url = "<?php echo e(url('ad/update')); ?>";
        formdata.append("ad_id",document.getElementById('id').value)
      }

      $("#modal").modal("hide");


      $.ajax({
        url: url,
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
        type:'POST',
        data:formdata,
        dataType : 'JSON',
        contentType: false,
        processData: false,
        success:function(response){
          if(response.status==1){
                Swal.fire({
                  title: "<?php echo e(__('Success')); ?>",
                  text: "<?php echo e(__('success')); ?>",
                  icon: 'success',
                  confirmButtonText: 'Ok'
                }).then((result) => {
                  location.reload();
                });
          } else {
            console.log(response.message);
            Swal.fire(
                "<?php echo e(__('Error')); ?>",
                response.message,
                'error'
            );
          }
        },
        error: function(data){
          var errors = data.responseJSON;
          console.log(errors);
          Swal.fire(
              "<?php echo e(__('Error')); ?>",
              errors.message,
              'error'
          );
          // Render the errors with js ...
        }
      });
    });

    $(document.body).on('click', '.delete', function() {

      var ad_id = $(this).attr('table_id');

      Swal.fire({
        title: "<?php echo e(__('Warning')); ?>",
        text: "<?php echo e(__('Are you sure?')); ?>",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: "<?php echo e(__('Delete')); ?>",
        cancelButtonText: "<?php echo e(__('Cancel')); ?>"
      }).then((result) => {
        if (result.isConfirmed) {

          $.ajax({
            url: "<?php echo e(url('ad/delete')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:{ad_id : ad_id},
            dataType : 'JSON',
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });


        }
      })
    });

    $(document.body).on('change', '.image-input', function() {
        const fileInput = document.querySelector('.image-input');
        if (fileInput.files[0]) {
          document.getElementById('uploaded-image').src = window.URL.createObjectURL(fileInput.files[0]);
        }
    });
    $(document.body).on('click', '.image-reset', function() {
      const fileInput = document.querySelector('.image-input');
      fileInput.value = '';
      document.getElementById('uploaded-image').src = document.getElementById('old-image').src;
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\njeek\resources\views/content/ads/list.blade.php ENDPATH**/ ?>