<?php $__env->startSection('title', __('Offers')); ?>

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-3">
  <span class="text-muted fw-light"><?php echo e(__('Offers')); ?> /</span> <?php echo e(__('Browse offers')); ?>

  <button type="button" class="btn btn-primary" id="create" style="float:right"><?php echo e(__('Add Offer')); ?></button>
</h4>

<!-- Basic Bootstrap Table -->
<div class="card">
  <h5 class="card-header"><?php echo e(__('Offers table')); ?></h5>
  <div class="table-responsive text-nowrap">
    <table class="table" id="laravel_datatable">
      <thead>
        <tr>
          <th>#</th>
          <th><?php echo e(__('Name Ar')); ?></th>
          <th><?php echo e(__('Name En')); ?></th>
          <th><?php echo e(__('Created at')); ?></th>
          <th><?php echo e(__('Categories')); ?></th>
          <th><?php echo e(__('Published')); ?></th>
          <th><?php echo e(__('Actions')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<div class="modal fade" id="modal"  aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="fw-bold py-1 mb-1"><?php echo e(__('Add/update offer')); ?></h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="text" id="form_type" hidden />
        <input type="text" class="form-control" id="id" name="id" hidden/>
        <form class="form-horizontal" onsubmit="event.preventDefault()" action="#"
          enctype="multipart/form-data" id="form">

            <div class="mb-3">
              <label class="form-label" for="name"><?php echo e(__('Name Ar')); ?></label>
              <input type="text" class="form-control" id="name" name="name"/>
            </div>

            <div class="mb-3">
              <label class="form-label" for="name_en"><?php echo e(__('Name En')); ?></label>
              <input type="text" class="form-control" id="name_en" name="name_en"/>
            </div>

            <div class="mb-3">
              <label class="form-label" for="categories"><?php echo e(__('Categories')); ?></label>
              <select class="selectpicker form-control" id="categories" name="categories" multiple>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>" > <?php echo e($category->name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

          <div class="mb-3" style="text-align: center">
            <button type="submit" id="submit" name="submit" class="btn btn-primary"><?php echo e(__('Send')); ?></button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
  $(document).ready(function(){
    load_data();
    function load_data() {
        //$.fn.dataTable.moment( 'YYYY-M-D' );
        var table = $('#laravel_datatable').DataTable({

            responsive: true,
            processing: true,
            serverSide: true,
            pageLength: 100,

            ajax: {
                url: "<?php echo e(url('offer/list')); ?>",
            },

            type: 'GET',

            columns: [

                {
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },

                {
                    data: 'name',
                    name: 'name'
                },

                {
                    data: 'name_en',
                    name: 'name_en'
                },

                {
                    data: 'created_at',
                    name: 'created_at'
                },


                {
                    data: 'categories',
                    name: 'categories'
                },

                {
                    data: 'is_published',
                    name: 'is_published',
                    render: function(data){
                          if(data == false){
                              return '<span class="badge bg-danger"><?php echo e(__("No")); ?></span>';
                            }else{
                              return '<span class="badge bg-success"><?php echo e(__("Yes")); ?></span>';
                            }
                          }
                },

                {
                    data: 'action',
                    name: 'action',
                    render:function(data){
                      /* return '<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu">'
                        +data+'</div></div>' */
                        return '<span>'+data+'</span>';
                    }
                }

            ]
        });
    }
    $('#create').on('click', function() {
      document.getElementById('form').reset();
      document.getElementById('form_type').value = "create";
      $('#categories').selectpicker('val', []);
      $("#modal").modal('show');
    });


    $(document.body).on('click', '.update', function() {
      document.getElementById('form').reset();
      document.getElementById('form_type').value = "update";
      var offer_id = $(this).attr('table_id');
      $("#id").val(offer_id);

      $.ajax({
          url: '<?php echo e(url('offer/update')); ?>',
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          type:'POST',
          data:{offer_id : offer_id},
          dataType : 'JSON',
          success:function(response){
              if(response.status==1){

                document.getElementById('name').value =  response.data.name;
                document.getElementById('name_en').value =  response.data.name_en;

                $.ajax({
                  url: '<?php echo e(url('category/get?all=1')); ?>',
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
                  type:'POST',
                  data:{offer_id : offer_id},
                  dataType : 'JSON',
                  success:function(response){
                      if(response.status==1){

                        var categories = document.getElementById('categories');
                        //subcategories.innerHTML = '<option value=""><?php echo e(__("Not selected")); ?></option>';
                        //console.log(response.data);
                        const getKey = (array,key) => array.map(a => a[key]);
                        var options = getKey(response.data,'id');
                        $('#categories').selectpicker('val', options);
                        $("#modal").modal("show");

                      }
                    }
                });

              }
            }
        });
    });

    $('#submit').on('click', function() {

      var formdata = new FormData();
      formdata.append('name',$("#name").val());
      formdata.append('name_en',$("#name_en").val());
      var categories = document.getElementById('categories');

      for (var i=0 ; i<categories.options.length ; i++) {
        if (categories.options[i].selected) {
          formdata.append(`categories[${i}]`,categories.options[i].value);
        }
      }

      var formtype = document.getElementById('form_type').value;

       if(formtype == "create"){
        url = "<?php echo e(url('offer/create')); ?>";
       }

      if(formtype == "update"){
        url = "<?php echo e(url('offer/update')); ?>";
        formdata.append("offer_id",document.getElementById('id').value)
      }

      $("#modal").modal("hide");


      $.ajax({
        url: url,
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
        type:'POST',
        data:formdata,
        dataType : 'JSON',
        contentType: false,
        processData: false,
        success:function(response){
          if(response.status==1){
                Swal.fire({
                  title: "<?php echo e(__('Success')); ?>",
                  text: "<?php echo e(__('success')); ?>",
                  icon: 'success',
                  confirmButtonText: 'Ok'
                }).then((result) => {
                  location.reload();
                });
          } else {
            console.log(response.message);
            Swal.fire(
                "<?php echo e(__('Error')); ?>",
                response.message,
                'error'
            );
          }
        },
        error: function(data){
          var errors = data.responseJSON;
          console.log(errors);
          Swal.fire(
              "<?php echo e(__('Error')); ?>",
              errors.message,
              'error'
          );
          // Render the errors with js ...
        }
      });
    });

    $(document.body).on('click', '.delete', function() {

      var offer_id = $(this).attr('table_id');

      Swal.fire({
        title: "<?php echo e(__('Warning')); ?>",
        text: "<?php echo e(__('Are you sure?')); ?>",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: "<?php echo e(__('Delete')); ?>",
        cancelButtonText: "<?php echo e(__('Cancel')); ?>"
      }).then((result) => {
        if (result.isConfirmed) {

          $.ajax({
            url: "<?php echo e(url('offer/delete')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:{offer_id : offer_id},
            dataType : 'JSON',
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });


        }
      })
    });

    $(document.body).on('click', '.add_to_home', function() {

      var offer_id = $(this).attr('table_id');

      Swal.fire({
        title: "<?php echo e(__('Warning')); ?>",
        text: "<?php echo e(__('Are you sure?')); ?>",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: "<?php echo e(__('Yes')); ?>",
        cancelButtonText: "<?php echo e(__('No')); ?>"
      }).then((result) => {
        if (result.isConfirmed) {

          $.ajax({
            url: "<?php echo e(url('section/add')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:{
              type : "offer",
              element : offer_id},
            dataType : 'JSON',
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });


        }
      })
    });

    $(document.body).on('click', '.remove_from_home', function() {

      var section_id = $(this).attr('table_id');

      Swal.fire({
        title: "<?php echo e(__('Warning')); ?>",
        text: "<?php echo e(__('Are you sure?')); ?>",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: "<?php echo e(__('Yes')); ?>",
        cancelButtonText: "<?php echo e(__('No')); ?>"
      }).then((result) => {
        if (result.isConfirmed) {

          $.ajax({
            url: "<?php echo e(url('section/delete')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:{section_id : section_id},
            dataType : 'JSON',
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });


        }
      })
      });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\njeek\resources\views/content/offers/list.blade.php ENDPATH**/ ?>