<?php $__env->startSection('title', __('Orders')); ?>

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-3">
  <span class="text-muted fw-light"><?php echo e(__('Orders')); ?> /</span> <?php echo e(__('Browse orders')); ?>

</h4>

<!-- Basic Bootstrap Table -->
<div class="card">
  <h5 class="card-header"><?php echo e(__('Orders table')); ?></h5>
  <div class="table-responsive text-nowrap">
    <table class="table" id="laravel_datatable">
      <thead>
        <tr>
          <th>#</th>
          <th><?php echo e(__('User')); ?></th>
          <th><?php echo e(__('Phone')); ?></th>
          <th><?php echo e(__('Created at')); ?></th>
          <th><?php echo e(__('Status')); ?></th>
          <th><?php echo e(__('Driver')); ?></th>
          <th><?php echo e(__('Actions')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>


<div class="modal fade" id="invoice_modal"  aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="fw-bold py-1 mb-1"><?php echo e(__('Create invoice')); ?></h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">


        <form class="form-horizontal" onsubmit="event.preventDefault()" action="#"
          enctype="multipart/form-data" id="invoice_form">

            <input type="text" id="invoice_order_id" name="order_id" hidden />

            

            <div class="mb-3">
              <label class="form-label" for="tax_amount"><?php echo e(__('Tax amount')); ?></label>
              <input type="number" class="form-control" id="tax_amount" name="tax_amount">
              </select>
            </div>

          <div class="mb-3" style="text-align: center">
            <button type="submit" id="submit_invoice" name="submit_invoice" class="btn btn-primary"><?php echo e(__('Send')); ?></button>
          </div>



        </form>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="payment_modal"  aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="fw-bold py-1 mb-1"><?php echo e(__('Order payment')); ?></h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form class="form-horizontal" onsubmit="event.preventDefault()" action="#"
          enctype="multipart/form-data" id="payment_form">

            <input type="text" id="payment_order_id" name="order_id" hidden />

            <div class="mb-3">
              <label class="form-label" for="payment_method"><?php echo e(__('Payment method')); ?></label>
              <select class="form-select" id="payment_method" name="payment_method">
                <option value="1" > <?php echo e(__('Card')); ?></option>
                <option value="2" > <?php echo e(__('Cash')); ?></option>
              </select>
            </div>


          <div class="mb-3" style="text-align: center">
            <button type="submit" id="submit_payment" name="submit_payment" class="btn btn-primary"><?php echo e(__('Send')); ?></button>
          </div>



        </form>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="driver_modal"  aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="fw-bold py-1 mb-1"><?php echo e(__('Approve order')); ?></h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form class="form-horizontal" onsubmit="event.preventDefault()" action="#"
          enctype="multipart/form-data" id="driver_form">


            <input type="text" id="driver_order_id" name="order_id" hidden />

            <div class="mb-3">
              <label class="form-label" for="driver_id"><?php echo e(__('Driver')); ?></label>
              <select class="form-select" id="driver_id" name="driver_id">
                <option value="" > <?php echo e(__('Select driver')); ?></option>
                <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($driver->id); ?>" > <?php echo e($driver->fullname()); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

          <div class="mb-3" style="text-align: center">
            <button type="submit" id="submit_driver" name="submit_driver" class="btn btn-primary"><?php echo e(__('Send')); ?></button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
  $(document).ready(function(){
    load_data();
    function load_data(category = null) {
        //$.fn.dataTable.moment( 'YYYY-M-D' );
        var table = $('#laravel_datatable').DataTable({

            responsive: true,
            processing: true,
            serverSide: true,

            ajax: {
                url: "<?php echo e(url('order/list')); ?>",
                type: 'GET',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            },

            columns: [

                {
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },

                {
                    data: 'user',
                    name: 'user'
                },

                {
                    data: 'phone',
                    name: 'phone'
                },

                {
                    data: 'created_at',
                    name: 'created_at'
                },

                {
                    data: 'status',
                    name: 'status',
                    render: function(data){
                          if(data == 'pending'){
                              return '<span class="badge bg-secondary"><?php echo e(__("pending")); ?></span>';
                            }
                            if(data == 'accepted'){
                              return '<span class="badge bg-primary"><?php echo e(__("accepted")); ?></span>';
                            }
                            if(data == 'canceled'){
                              return '<span class="badge bg-danger"><?php echo e(__("canceled")); ?></span>';
                            }
                            if(data == 'ongoing'){
                              return '<span class="badge bg-info"><?php echo e(__("ongoing")); ?></span>';
                            }
                            if(data == 'delivered'){
                              return '<span class="badge bg-success"><?php echo e(__("delivered")); ?></span>';
                            }
                          }
                },


                {
                    data: 'driver',
                    name: 'driver'
                },

                {
                    data: 'action',
                    name: 'action',
                    render:function(data){
                      return '<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu">'
                        +data+'</div></div>'
                    }
                }

            ]
        });
    }
  });

  $(document.body).on('click', '.refuse', function() {

      var order_id = $(this).attr('table_id');

      Swal.fire({
        title: "<?php echo e(__('Warning')); ?>",
        text: "<?php echo e(__('Are you sure?')); ?>",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: "<?php echo e(__('Yes')); ?>",
        cancelButtonText: "<?php echo e(__('No')); ?>"
      }).then((result) => {
        if (result.isConfirmed) {

          $.ajax({
            url: "<?php echo e(url('order/update')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:{
              order_id : order_id,
              status : "canceled"},
            dataType : 'JSON',
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });


        }
      })

  });

  $(document.body).on('click', '.accept', function() {
      document.getElementById('invoice_form').reset();
      var order_id = $(this).attr('table_id');
      document.getElementById('invoice_order_id').value = order_id;
      $("#invoice_modal").modal('show');
  });

  $(document.body).on('click', '.ship', function() {
    document.getElementById('driver_form').reset();
    var order_id = $(this).attr('table_id');
    document.getElementById('driver_order_id').value = order_id;
    $("#driver_modal").modal('show');
  });

  $(document.body).on('click', '.payment', function() {
    document.getElementById('payment_form').reset();
    var order_id = $(this).attr('table_id');
    document.getElementById('payment_order_id').value = order_id;
    $("#payment_modal").modal('show');
  });

  $('#submit_invoice').on('click', function() {
    var formdata = new FormData($("#invoice_form")[0]);
    formdata.append('status','accepted');
    $("#driver_modal").modal('hide');

    $.ajax({
            url: "<?php echo e(url('order/update')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:formdata,
            dataType : 'JSON',
            contentType: false,
            processData: false,
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });

  });

  $('#submit_driver').on('click', function() {
    var formdata = new FormData($("#driver_form")[0]);
    formdata.append('status','ongoing');
    $("#driver_modal").modal('show');

    $.ajax({
            url: "<?php echo e(url('order/update')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:formdata,
            dataType : 'JSON',
            contentType: false,
            processData: false,
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });

  });

  $('#submit_payment').on('click', function() {
    var formdata = new FormData($("#payment_form")[0]);
    formdata.append('status','delivered');
    $("#payment_modal").modal('hide');

    $.ajax({
            url: "<?php echo e(url('order/update')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:formdata,
            dataType : 'JSON',
            contentType: false,
            processData: false,
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });
  });


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\njeek\resources\views/content/orders/list.blade.php ENDPATH**/ ?>