<!-- Footer-->
<footer class="content-footer footer bg-footer-theme">
  
</footer>
<!--/ Footer-->
<?php /**PATH C:\xampp\htdocs\hoskashop\resources\views/layouts/sections/footer/footer.blade.php ENDPATH**/ ?>