<?php $__env->startSection('title', 'Dashboard - Analytics'); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 mb-4 order-0">
    <div class="card">
      <div class="d-flex align-items-end row">
        <div class="col-sm-7">
          <div class="card-body">
            <h5 class="card-title text-primary"><?php echo e(__('Welcome to your admin dashboard!')); ?> 🎉</h5>
            <p class="mb-4"><?php echo e(__('Here, you can asily track annual revenue trends, monitor weekly and monthly order patterns, and gain insights into user behavior through comprehensive reports.')); ?></p>
          </div>
        </div>
        <div class="col-sm-5 text-center text-sm-left">
          <div class="card-body pb-0 px-0 px-md-4">
            <img src="<?php echo e(asset('assets/img/illustrations/man-with-laptop-light.png')); ?>" height="140" alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png" data-app-light-img="illustrations/man-with-laptop-light.png">
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Total Revenue -->
  <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
    <div class="card">
      <div class="row row-bordered g-0">
        <div class="col-md-8">
          <h5 class="card-header m-0 me-2 pb-3"><?php echo e(__('Total Revenue')); ?></h5>
          <div id="totalRevenueChart" class="px-2"></div>
        </div>
        <div class="col-md-4">
          <div class="card-body">
            <div class="text-center">
              <strong><?php echo e(__('This Year')); ?></strong>
            </div>
          </div>
          <div id="growthChart"></div>
          <div class="text-center fw-semibold pt-3 mb-2"><?php echo e(__('Total paid :')); ?> <?php echo e($total_paid); ?> </div>

          <div class="d-flex px-xxl-4 px-lg-2 p-4 gap-xxl-3 gap-lg-1 gap-3 justify-content-between">
            <div class="d-flex">
              <div class="me-2">
                <span class="badge bg-label-primary p-2"><i class="bx bx-dollar text-primary"></i></span>
              </div>
              <div class="d-flex flex-column">
                <small><?php echo e(__('Cash')); ?></small>
                <h6 class="mb-0"><?php echo e($paid_cash); ?></h6>
              </div>
            </div>
            <div class="d-flex">
              <div class="me-2">
                <span class="badge bg-label-info p-2"><i class="bx bx-wallet text-info"></i></span>
              </div>
              <div class="d-flex flex-column">
                <small><?php echo e(__('Card')); ?></small>
                <h6 class="mb-0"><?php echo e($paid_card); ?></h6>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<div class="row">
  <!-- Order Statistics -->
  <div class="col-md-6 col-lg-4 col-xl-4 order-0 mb-4">
    <div class="card h-100">
      <div class="card-header d-flex align-items-center justify-content-between pb-0">
        <div class="card-title mb-0">
          <h5 class="m-0 me-2"><?php echo e(__('Monthly Orders Report')); ?></h5>
          
        </div>
      </div>
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div class="d-flex flex-column align-items-center gap-1">
            <h2 class="mb-2"><?php echo e($orders_this_month); ?></h2>
            <span><?php echo e(__('Monthly Orders')); ?></span>
          </div>
          <div id="orderStatisticsChart"></div>
        </div>
        <ul class="p-0 m-0">
          <li class="d-flex mb-4 pb-1">
            <div class="avatar flex-shrink-0 me-3">
              <span class="badge bg-label-secondary"><i class="bx bx-time bx-sm"></i></span>
            </div>
            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
              <div class="me-2">
                <h6 class="mb-0"><?php echo e(__('Pending')); ?></h6>
              </div>
              <div class="user-progress d-flex align-items-center gap-1">
                <h6 class="mb-0"><?php echo e($pending); ?></h6>
              </div>
            </div>
          </li>
          <li class="d-flex mb-4 pb-1">
            <div class="avatar flex-shrink-0 me-3">
              <span class="badge bg-label-purple"><i class="bx bx-check-circle bx-sm"></i></span>
            </div>
            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
              <div class="me-2">
                <h6 class="mb-0"><?php echo e(__('Accepted')); ?></h6>
              </div>
              <div class="user-progress d-flex align-items-center gap-1">
                <h6 class="mb-0"><?php echo e($accepted); ?></h6>
              </div>
            </div>
          </li>
          <li class="d-flex mb-4 pb-1">
            <div class="avatar flex-shrink-0 me-3">
              <span class="badge bg-label-danger"><i class="bx bx-x-circle bx-sm"></i></span>
            </div>
            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
              <div class="me-2">
                <h6 class="mb-0"><?php echo e(__('Canceled')); ?></h6>
              </div>
              <div class="user-progress d-flex align-items-center gap-1">
                <h6 class="mb-0"><?php echo e($canceled); ?></h6>
              </div>
            </div>
          </li>
          <li class="d-flex mb-4 pb-1">
            <div class="avatar flex-shrink-0 me-3">
              <span class="badge bg-label-info"><i class="bx bxs-truck bx-sm"></i></span>
            </div>
            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
              <div class="me-2">
                <h6 class="mb-0"><?php echo e(__('Ongoing')); ?></h6>
              </div>
              <div class="user-progress d-flex align-items-center gap-1">
                <h6 class="mb-0"><?php echo e($ongoing); ?></h6>
              </div>
            </div>
          </li>
          <li class="d-flex mb-4 pb-1">
            <div class="avatar flex-shrink-0 me-3">
              <span class="badge bg-label-success"><i class="bx bx-package bx-sm"></i></span>
            </div>
            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
              <div class="me-2">
                <h6 class="mb-0"><?php echo e(__('Delivered')); ?></h6>
              </div>
              <div class="user-progress d-flex align-items-center gap-1">
                <h6 class="mb-0"><?php echo e($delivered); ?></h6>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <!--/ Order Statistics -->

  <!-- Expense Overview -->
  <div class="col-md-6 col-lg-4 order-1 mb-4">
    <div class="card h-100">
      <div class="card-header d-flex align-items-center justify-content-between pb-0">
        <div class="card-title mb-0">
          <h5 class="m-0 me-2"><?php echo e(__('Weekly Orders Report')); ?></h5>
          
        </div>
      </div>
      <div class="card-body px-0">
        <div class="tab-content p-0">
          <div class="tab-pane fade show active" id="navs-tabs-line-card-income" role="tabpanel">
            <div class="d-flex p-4 pt-3">
              <div class="avatar flex-shrink-0 me-3">
                <span class="badge bg-label-info"><i class="bx bx-spreadsheet bx-sm"></i></span>
              </div>
              <div>
                <small class="text-muted d-block"><?php echo e(__('Weekly orders')); ?></small>
                <div class="d-flex align-items-center">
                  <h6 class="mb-0 me-1"><?php echo e($orders_this_week); ?></h6>
                  
                </div>
              </div>
            </div>
            <div id="ordersChart"></div>
            <div class="d-flex justify-content-center pt-4 gap-2">
              <div class="flex-shrink-0">
                <div id="todayOrders"></div>
              </div>
              <div>
                <p class="mb-n1 mt-1"><?php echo e(__("Today's orders")); ?></p>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Expense Overview -->

  <!-- Transactions -->
  <div class="col-md-6 col-lg-4 order-1 mb-4">
    <div class="card h-100">
      <div class="card-header d-flex align-items-center justify-content-between pb-0">
        <div class="card-title mb-0">
          <h5 class="m-0 me-2"><?php echo e(__('Weekly Users Report')); ?></h5>
          
        </div>
      </div>
      <div class="card-body px-0">
        <div class="tab-content p-0">
          <div class="tab-pane fade show active" id="navs-tabs-line-card-income" role="tabpanel">
            <div class="d-flex p-4 pt-3">
              <div class="avatar flex-shrink-0 me-3">
                <span class="badge bg-label-success"><i class="bx bx-user bx-sm"></i></span>
              </div>
              <div>
                <small class="text-muted d-block"><?php echo e(__('Weekly users')); ?></small>
                <div class="d-flex align-items-center">
                  <h6 class="mb-0 me-1"><?php echo e($users_this_week); ?></h6>
                  
                </div>
              </div>
            </div>
            <div id="usersChart"></div>
            <div class="d-flex justify-content-center pt-4 gap-2">
              <div class="flex-shrink-0">
                <div id="todayUsers"></div>
              </div>
              <div>
                <p class="mb-n1 mt-1"><?php echo e(__("Today's users")); ?></p>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Transactions -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\njeek\resources\views/content/dashboard/dashboards-analytics.blade.php ENDPATH**/ ?>