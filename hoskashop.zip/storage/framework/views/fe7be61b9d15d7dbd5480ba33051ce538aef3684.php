<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo e($invoice->name); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <style type="text/css" media="screen">
        html {
            font-family: sans-serif;
            line-height: 1.15;
            margin: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            text-align: left;
            background-color: #fff;
            font-size: 10px;
            margin: 36pt;
        }

        h4 {
            margin-top: 0;
            margin-bottom: 0.5rem;
        }

        p {
            margin-top: 0;
            margin-bottom: 1rem;
        }

        strong {
            font-weight: bolder;
        }

        img {
            vertical-align: middle;
            border-style: none;
        }

        table {
            border-collapse: collapse;
        }

        th {
            text-align: inherit;
        }

        h4,
        .h4 {
            margin-bottom: 0.5rem;
            font-weight: 500;
            line-height: 1.2;
        }

        h4,
        .h4 {
            font-size: 1.5rem;
        }

        .table {
            width: 100%;
            margin-bottom: 1rem;
            color: #212529;
        }

        .table th,
        .table td {
            padding: 0.75rem;
            vertical-align: top;
        }

        .table.table-items td {
            border-top: 1px solid #dee2e6;
        }

        .table thead th {
            vertical-align: bottom;
            border-bottom: 2px solid #dee2e6;
        }

        .mt-5 {
            margin-top: 3rem !important;
        }

        .pr-0,
        .px-0 {
            padding-right: 0 !important;
        }

        .pl-0,
        .px-0 {
            padding-left: 0 !important;
        }

        .text-right {
            text-align: right !important;
        }

        .text-center {
            text-align: center !important;
        }

        .text-uppercase {
            text-transform: uppercase !important;
        }

        * {
            font-family: "DejaVu Sans";
        }

        body,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        table,
        th,
        tr,
        td,
        p,
        div {
            line-height: 1.1;
        }

        .party-header {
            font-size: 1.5rem;
            font-weight: 400;
        }

        .total-amount {
            font-size: 12px;
            font-weight: 700;
        }

        .border-0 {
            border: none !important;
        }

        .cool-gray {
            color: #6B7280;
        }

        .center {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>

<body>
    
    


    <table class="table">
        <tbody>
            <tr>
                
                <td class="border-0 pl-0" width="40%"
                    style="text-align: center;
                    vertical-align: middle;">
                    
                    <?php if(Session::get('locale') == 'en'): ?>
                        <p><?php echo e(__('order_id')); ?> : <strong><?php echo e($invoice->getSerialNumber()); ?></strong></p>
                        <p><?php echo e(__('order_date')); ?> : <strong><?php echo e($invoice->getDate()); ?></strong></p>
                    <?php else: ?>
                        <p><strong><?php echo e($invoice->getSerialNumber()); ?></strong><?php echo e(__('order_id')); ?> : </p>
                        <p><strong><?php echo e($invoice->getDate()); ?></strong><?php echo e(__('order_date')); ?> : </p>
                    <?php endif; ?>
                </td>

                <td class="border-0 pl-0" width="20%" style="text-align: center;vertical-align: middle;">
                    <?php if($invoice->logo): ?>
                        <img src="<?php echo e($invoice->getLogo()); ?>" alt="logo" height="100" class="center">
                    <?php endif; ?>
                </td>

                <td class="border-0 pl-0" width="40%"
                    style="text-align: center;
                    vertical-align: middle;">
                    
                    <?php if(Session::get('locale') == 'en'): ?>
                        <p><?php echo e(__('buyer_name')); ?> : <strong><?php echo e($invoice->buyer->name); ?></strong></p>
                        <p><?php echo e(__('buyer_phone')); ?> : <strong><?php echo e($invoice->buyer->phone); ?></strong></p>
                    <?php else: ?>
                        <p><strong><?php echo e($invoice->buyer->name); ?></strong><?php echo e(__('buyer_name')); ?> : </p>
                        <p><strong><?php echo e($invoice->buyer->phone); ?></strong><?php echo e(__('buyer_phone')); ?> : </p>
                    <?php endif; ?>
                </td>
            </tr>
        </tbody>
    </table>

    
    

    
    <?php if(Session::get('locale') == 'en'): ?>
        <table class="table table-items">
            <thead>
                <tr>
                    <th scope="col" class="border-0 pl-0"><?php echo e(__('description')); ?></th>
                    <?php if($invoice->hasItemUnits): ?>
                        <th scope="col" class="text-center border-0"><?php echo e(__('units')); ?></th>
                    <?php endif; ?>
                    <th scope="col" class="text-center border-0"><?php echo e(__('quantity')); ?></th>
                    <th scope="col" class="text-right border-0"><?php echo e(__('price')); ?></th>
                    <?php if($invoice->hasItemDiscount): ?>
                        <th scope="col" class="text-right border-0"><?php echo e(__('discount')); ?></th>
                    <?php endif; ?>
                    <?php if($invoice->hasItemTax): ?>
                        <th scope="col" class="text-right border-0"><?php echo e(__('tax')); ?></th>
                    <?php endif; ?>
                    <th scope="col" class="text-right border-0 pr-0"><?php echo e(__('sub_total')); ?></th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="pl-0">
                            <?php echo e($item->title); ?>


                            <?php if($item->description): ?>
                                <p class="cool-gray"><?php echo e($item->description); ?></p>
                            <?php endif; ?>
                        </td>
                        <?php if($invoice->hasItemUnits): ?>
                            <td class="text-center"><?php echo e($item->units); ?></td>
                        <?php endif; ?>
                        <td class="text-center"><?php echo e($item->quantity); ?></td>
                        <td class="text-right">
                            <?php echo e($invoice->formatCurrency($item->price_per_unit)); ?>

                        </td>
                        <?php if($invoice->hasItemDiscount): ?>
                            <td class="text-right">
                                <?php echo e($invoice->formatCurrency($item->discount)); ?>

                            </td>
                        <?php endif; ?>
                        <?php if($invoice->hasItemTax): ?>
                            <td class="text-right">
                                <?php echo e($invoice->formatCurrency($item->tax)); ?>

                            </td>
                        <?php endif; ?>

                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($item->sub_total_price)); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php if($invoice->hasItemOrInvoiceDiscount()): ?>
                    <tr>
                        <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                        <td class="text-right pl-0"><?php echo e(__('total_discount')); ?></td>
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($invoice->total_discount)); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                <?php if($invoice->taxable_amount): ?>
                    <tr>
                        <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                        <td class="text-right pl-0"><?php echo e(__('taxable_amount')); ?></td>
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($invoice->taxable_amount)); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                <?php if($invoice->tax_rate): ?>
                    <tr>
                        <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                        <td class="text-right pl-0"><?php echo e(__('tax_rate')); ?></td>
                        <td class="text-right pr-0">
                            <?php echo e($invoice->tax_rate); ?>%
                        </td>
                    </tr>
                <?php endif; ?>
                <?php if($invoice->hasItemOrInvoiceTax()): ?>
                    <tr>
                        <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                        <td class="text-right pl-0"><?php echo e(__('total_taxes')); ?></td>
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($invoice->total_taxes)); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                <?php if($invoice->shipping_amount): ?>
                    <tr>
                        <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                        <td class="text-right pl-0"><?php echo e(__('shipping')); ?></td>
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($invoice->shipping_amount)); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                    <td class="text-right pl-0"><?php echo e(__('total_amount')); ?></td>
                    <td class="text-right pr-0 total-amount">
                        <?php echo e($invoice->formatCurrency($invoice->total_amount)); ?>

                    </td>
                </tr>
            </tbody>
        </table>
    <?php else: ?>
        <table class="table table-items">
            <thead>
                <tr>
                    <th scope="col" class="text-right border-0 pr-0"><?php echo e(__('sub_total')); ?></th>
                    <?php if($invoice->hasItemTax): ?>
                        <th scope="col" class="text-right border-0"><?php echo e(__('tax')); ?></th>
                    <?php endif; ?>
                    <?php if($invoice->hasItemDiscount): ?>
                        <th scope="col" class="text-right border-0"><?php echo e(__('discount')); ?></th>
                    <?php endif; ?>
                    <th scope="col" class="text-right border-0"><?php echo e(__('price')); ?></th>
                    <th scope="col" class="text-center border-0"><?php echo e(__('quantity')); ?></th>
                    <?php if($invoice->hasItemUnits): ?>
                        <th scope="col" class="text-center border-0"><?php echo e(__('units')); ?></th>
                    <?php endif; ?>
                    <th scope="col" class="border-0 pl-0"><?php echo e(__('description')); ?></th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($item->sub_total_price)); ?>

                        </td>
                        <?php if($invoice->hasItemTax): ?>
                            <td class="text-right">
                                <?php echo e($invoice->formatCurrency($item->tax)); ?>

                            </td>
                        <?php endif; ?>
                        <?php if($invoice->hasItemDiscount): ?>
                            <td class="text-right">
                                <?php echo e($invoice->formatCurrency($item->discount)); ?>

                            </td>
                        <?php endif; ?>
                        <td class="text-right">
                            <?php echo e($invoice->formatCurrency($item->price_per_unit)); ?>

                        </td>
                        <td class="text-center"><?php echo e($item->quantity); ?></td>
                        <?php if($invoice->hasItemUnits): ?>
                            <td class="text-center"><?php echo e($item->units); ?></td>
                        <?php endif; ?>
                        <td class="pl-0">
                            <?php echo e($item->title); ?>


                            <?php if($item->description): ?>
                                <p class="cool-gray"><?php echo e($item->description); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php if($invoice->hasItemOrInvoiceDiscount()): ?>
                    <tr>
                        
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($invoice->total_discount)); ?>

                        </td>
                        <td class="text-right pl-0"><?php echo e(__('total_discount')); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if($invoice->taxable_amount): ?>
                    <tr>
                        
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($invoice->taxable_amount)); ?>

                        </td>
                        <td class="text-right pl-0"><?php echo e(__('taxable_amount')); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if($invoice->tax_rate): ?>
                    <tr>
                        
                        <td class="text-right pr-0">
                            <?php echo e($invoice->tax_rate); ?>%
                        </td>
                        <td class="text-right pl-0"><?php echo e(__('tax_rate')); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if($invoice->hasItemOrInvoiceTax()): ?>
                    <tr>
                        
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($invoice->total_taxes)); ?>

                        </td>
                        <td class="text-right pl-0"><?php echo e(__('total_taxes')); ?></td>
                    </tr>
                <?php endif; ?>

                <?php if($invoice->shipping_amount): ?>
                    <tr>
                        
                        <td class="text-right pr-0">
                            <?php echo e($invoice->formatCurrency($invoice->shipping_amount)); ?>

                        </td>
                        <td class="text-right pl-0"><?php echo e(__('shipping')); ?></td>
                    </tr>
                <?php endif; ?>
                <tr>
                    
                    <td class="text-right pr-0 total-amount">
                        <?php echo e($invoice->formatCurrency($invoice->total_amount)); ?>

                    </td>
                    <td class="text-right pl-0"><?php echo e(__('total_amount')); ?></td>

                </tr>
            </tbody>
        </table>

    <?php endif; ?>
    <?php if($invoice->notes): ?>
    <table class="table">
            <thead>
                <th class="border-0 pl-0" width="100%" style="text-align: center;vertical-align: top;padding: 0;">
                    <p><?php echo e(__('notes')); ?></p>
                </th>
            </thead>
            <tbody>


                <tr>

                    <td class="border-0 pl-0" width="100%" style="text-align: center;vertical-align: top;padding: 0;">
                        <p><?php echo e($invoice->notes); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?>
    <table class="table">
        <tbody>
            <tr>
                <td class="border-0 pl-0" width="100%"
                    style="text-align: center;
                  vertical-align: middle;">

                    
                    <p><?php echo e(__('print_date')); ?> : <?php echo e(now()); ?></p>
                    
                </td>
            </tr>
        </tbody>
    </table>

    

    

    <script type="text/php">
            if (isset($pdf) && $PAGE_COUNT > 1) {
                $text = "Page {PAGE_NUM} / {PAGE_COUNT}";
                $size = 10;
                $font = $fontMetrics->getFont("Verdana");
                $width = $fontMetrics->get_text_width($text, $font, $size) / 2;
                $x = ($pdf->get_width() - $width);
                $y = $pdf->get_height() - 35;
                $pdf->page_text($x, $y, $text, $font, $size);
            }
        </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\njeek\vendor\laraveldaily\laravel-invoices\src/../resources/views/templates/default.blade.php ENDPATH**/ ?>