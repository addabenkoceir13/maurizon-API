<!-- laravel style -->
<script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>

<!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
<script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>

<!-- beautify ignore:end -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="async" src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];

  function gtag() {
    dataLayer.push(arguments);
  }
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');

</script>
<?php /**PATH C:\xampp\htdocs\sneat-html-admin-template\html-laravel-free\full-version\resources\views/layouts/sections/scriptsIncludes.blade.php ENDPATH**/ ?>