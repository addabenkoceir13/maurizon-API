<!DOCTYPE html>

<html class="light-style layout-menu-fixed" data-theme="theme-default" data-assets-path="<?php echo e(asset('/assets') . '/'); ?>" data-base-url="<?php echo e(url('/')); ?>" data-framework="laravel" data-template="vertical-menu-laravel-template-free">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('variables.templateName')); ?></title>
  
  <!-- laravel CRUD token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <!-- Canonical SEO -->
  
  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon/favicon.ico')); ?>" />

  <!-- Include Styles -->
  <?php echo $__env->make('layouts/sections/styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Include Scripts for customizer, helper, analytics, config -->
  <?php echo $__env->make('layouts/sections/scriptsIncludes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
  <!-- Layout Content -->
  <?php echo $__env->yieldContent('layoutContent'); ?>
  <!--/ Layout Content -->

  
  
  

  <!-- Include Scripts -->
  <?php echo $__env->make('layouts/sections/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

  <!-- fcm web push notifications -->



<script src="https://cdnjs.cloudflare.com/ajax/libs/firebase/10.4.0/firebase-app-compat.min.js" integrity="sha512-0MTONB8k6iUesCTubXQcwvZ1PRbzPAK9PoEri2cbwFnxtcdaUFByAZlC8IUNZM3pe8Icdsdg4KhprzwQGUSsJw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/firebase/10.4.0/firebase-messaging-compat.min.js" integrity="sha512-G0FjvLkehmMADmKYeycWJzWPEP431DlO1+L3XBF7PhHpwhZK7DZ3L2qI9XlMof0Tm29fZwHlqEhe0PwLo+2xlQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type='module'>



const firebaseConfig = {
  apiKey: "AIzaSyAMyRsB9u4w1IbWNl0n0gGQd0LPE1jjU4c",
  authDomain: "njeek-eeca7.firebaseapp.com",
  projectId: "njeek-eeca7",
  storageBucket: "njeek-eeca7.appspot.com",
  messagingSenderId: "150919195413",
  appId: "1:150919195413:web:ee3178e4e7dd600462971c",
  measurementId: "G-PT06263J26"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

 // Retrieve firebase messaging
 const messaging = firebase.messaging();

//const messaging = getMessaging();
// Add the public key generated from the console here.
messaging.getToken({ vapidKey: 'BDZ7ZoNnhqYmTvdkCd3bQ4ncxarcNA-LpKw34kr3yfOr-V9u0w0LZbnh2FkdMTIA8uSlVXEGGdOoSrSqw5KqBes' }).then((currentToken) => {
  if (currentToken) {
    //console.log(currentToken);
    $.ajax({
          url: '<?php echo e(url('user/update')); ?>',
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          type:'POST',
          data:{
            fcm_token : currentToken
          },
          dataType : 'JSON',
        });
  } else {
    // Show permission request UI
    console.log('No registration token available. Request permission to generate one.');
    // ...
  }
}).catch((err) => {
  console.log('An error occurred while retrieving token. ', err);
  // ...
});


</script>

</html>
<?php /**PATH C:\xampp\htdocs\njeek\resources\views/layouts/commonMaster.blade.php ENDPATH**/ ?>