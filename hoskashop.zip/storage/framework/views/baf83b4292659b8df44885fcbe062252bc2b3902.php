<?php $__env->startSection('title', __($documentation->name)); ?>

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-3">
  <span class="text-muted fw-light"><?php echo e(__('Documentation')); ?> / </span><?php echo e(__($documentation->name)); ?>

</h4>

<div class="card mb-4">
  
  <div class="card-body">

    <form class="form-horizontal" onsubmit="event.preventDefault()" action="#"
          enctype="multipart/form-data" id="form">

        <div class="row mb-3">
            <textarea id="documentation" name="<?php echo e(Session::get('locale') == 'en' ? 'content_en' : 'content_ar'); ?>" class="form-control" rows="15" style="height: 375;" dir="rtl" disabled><?php echo e(Session::get('locale') == 'en' ? $documentation->content_en : $documentation->content_ar); ?></textarea>
            <input type="text" id='name' name="name" value="<?php echo e($documentation->name); ?>" hidden/>
        </div>
    </form>

    <div class="col" style="text-align: center">
      <button id='edit' class="btn btn-primary"><?php echo e(__('Edit')); ?></button>
      <div id="submit_cancel_div" hidden>
        <button id='submit' class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
        <button id='cancel' class="btn btn-secondary"><?php echo e(__('Cancel')); ?></button>
      </div>
    </div>


  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
<script>

  $(document).ready(function(){

    $('#edit').on('click', function() {
      document.getElementById('edit').hidden = true;
      document.getElementById('submit_cancel_div').hidden = false;
      document.getElementById('documentation').disabled = false;
    });

    $('#cancel').on('click', function() {
      document.getElementById('edit').hidden = false;
      document.getElementById('submit_cancel_div').hidden = true;
      document.getElementById('documentation').disabled = true;
    });

    $('#submit').on('click', function() {

      /* var formdata = new FormData();
      const parser = new DOMParser();
      var documentation = document.getElementById('documentation');
      var html = parser.parseFromString(documentation.innerHTML,'text/html')
      formdata.append('name',document.getElementById('name').value);
      formdata.append(documentation.getAttribute("name"),html.body.innerHTML); */

      var formdata = new FormData($("#form")[0]);

      $.ajax({
        url: '<?php echo e(url('documentation/update')); ?>',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type:'POST',
        data:formdata,
        dataType : 'JSON',
        contentType: false,
        processData: false,
        success:function(response){
            if(response.status==1){
              Swal.fire(
                  "<?php echo e(__('Success')); ?>",
                  "<?php echo e(__('success')); ?>",
                  'success'
              ).then(function(){
                location.reload();
              });
            } else {
              console.log(response.message);
              Swal.fire(
                  "<?php echo e(__('Error')); ?>",
                  response.message,
                  'error'
              );
            }
        },
        error: function(data){
          var errors = data.responseJSON;
          console.log(errors);
          Swal.fire(
              "<?php echo e(__('Error')); ?>",
              errors.message,
              'error'
          );
          // Render the errors with js ...
        }


      });
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hoskashop\resources\views/content/documentation/index.blade.php ENDPATH**/ ?>