<?php $__env->startSection('title', __('Notices')); ?>

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-3">
  <span class="text-muted fw-light"><?php echo e(__('Notices')); ?> /</span> <?php echo e(__('Browse notices')); ?>

  <button type="button" id="add" class="btn rounded-pill btn-primary" style="float: right;"><?php echo e(__('Add notice')); ?></button>
</h4>

<!-- Basic Bootstrap Table -->
<div class="card">
  <h5 class="card-header"><?php echo e(__('Notices table')); ?></h5>
  <div class="table-responsive text-nowrap">
    <table class="table" id="laravel_datatable">
      <thead>
        <tr>
          <th>#</th>
          <th><?php echo e(__('Notice')); ?></th>
          <th><?php echo e(__('Created at')); ?></th>
          <th><?php echo e(__('Notice type')); ?></th>
          
          <th><?php echo e(__('Actions')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>


<div class="modal fade" id="add_modal"  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="fw-bold py-1 mb-1"><?php echo e(__('Add notice')); ?></h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" onsubmit="event.preventDefault()" action="#"
          enctype="multipart/form-data" id="add_form">
          
            <div class="mb-3">
              <label class="form-label" for="title_ar"><?php echo e(__('Title')); ?></label>
              <div class="input-group input-group-merge">
                <input type="text" class="form-control" name="title_ar" placeholder="<?php echo e(__('Title in arabic')); ?>"/>
                <input type="text" class="form-control" name="title_en" placeholder="<?php echo e(__('Title in english')); ?>"/>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label" for="content_ar"><?php echo e(__('Content in arabic')); ?></label>
              <textarea class="form-control" name="content_ar" rows="3" style="height: 75px;"></textarea>
            </div>

            <div class="mb-3">
              <label class="form-label" for="notice_content"><?php echo e(__('Content in english')); ?></label>
              <textarea class="form-control" name="content_en" rows="3" style="height: 75px;"></textarea>
            </div>


            <div class="mb-3">
              <label class="form-label" for="type"><?php echo e(__('Notice type')); ?></label>
              <select class="form-select" name="type">
                <option value="0"><?php echo e(__('Select type')); ?></option>
                <option value="1"><?php echo e(__('Offer Notice')); ?></option>
                <option value="2"><?php echo e(__('Update Notice')); ?></option>
              </select>
            </div>
            <br>
          
          <div class="mb-3" style="text-align: center">
            <button type="submit" id="submit" name="submit" class="btn btn-primary"><?php echo e(__('Send')); ?></button>
          </div>
          
        </form>
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="view_modal"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="fw-bold py-1 mb-1"><?php echo e(__('Notice content')); ?></h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

            <div class="mb-3">
              <label class="form-label" for="title"><?php echo e(__('Title')); ?></label>
              <div class="input-group input-group-merge">
                <input type="text" class="form-control" id="title_ar" disabled/>
                <input type="text" class="form-control" id="title_en" disabled/>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label" for="notice_content"><?php echo e(__('Content in arabic')); ?></label>
              <textarea class="form-control" id="content_ar" rows="5" style="height: 125px;" disabled></textarea>
            </div>

            <div class="mb-3">
              <label class="form-label" for="notice_content"><?php echo e(__('Content in english')); ?></label>
              <textarea class="form-control" id="content_en" rows="5" style="height: 125px;" disabled></textarea>
            </div>

          
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
  $(document).ready(function(){
    load_data();
    function load_data() {
        $.fn.dataTable.moment( 'YYYY-M-D' );
        var table = $('#laravel_datatable').DataTable({

            responsive: true,
            processing: true,
            serverSide: true,

            ajax: {
                url: "<?php echo e(url('notice/list')); ?>",
            },

            type: 'GET',

            columns: [

                {
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },

                {
                    data: 'title',
                    name: 'title'
                },

                {
                    data: 'created_at',
                    name: 'created_at'
                },

                {
                    data: 'type',
                    name: 'type',
                    render: function(data){
                        if(data == 1){
                            return '<span class="badge bg-success"><?php echo e(__("Offer Notice")); ?></span>';
                          }else if(data == 2){
                            return '<span class="badge bg-info"><?php echo e(__("Update Notice")); ?></span>';
                          }else{
                            return '<span class="badge bg-secondary"><?php echo e(__("Other")); ?></span>';
                          }
                        }
                },


                {
                    data: 'action',
                    name: 'action',
                    render:function(data){
                      /* return '<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu">'
                        +data+'</div></div>' */
                        return '<span>'+data+'</span>';
                    }
                }

            ]
        });
    }



    $('#add').on('click',function(){
      $("#add_modal").modal('show');
    });

    $('#submit').on('click', function() {
      var queryString = new FormData($("#add_form")[0]);

      $.ajax({
        url: '<?php echo e(url('notice/create')); ?>',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type:'POST',
        data:queryString,
        dataType : 'JSON',
        contentType: false,
        processData: false,
        success:function(response){
            if(response.status==1){
              $("#add_modal").modal('hide');
              Swal.fire(
                  'Success',
                  "<?php echo e(__('success')); ?>",
                  'success'
              ).then((result)=>{
                    location.reload();
                });
            } else {
              console.log(response.message);
              Swal.fire(
                  "<?php echo e(__('Error')); ?>",
                  response.message,
                  'error'
              );
            }
        },
        error: function(data){
          var errors = data.responseJSON;
          console.log(errors);
          Swal.fire(
              "<?php echo e(__('Error')); ?>",
              errors.message,
              'error'
          );
          // Render the errors with js ...
        }


      });
    });

    $(document.body).on('click','.view', function() {
      notice_id = $(this).attr('table_id');
      $.ajax({
          url: '<?php echo e(url('notice/update')); ?>',
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          type:'POST',
          data:{
            notice_id : notice_id,
          },
          dataType : 'JSON',
          success:function(response){
              if(response.status==1){

                //console.log(response.data)
                $("#title_ar").val(response.data.title_ar);
                $("#title_en").val(response.data.title_en);
                $("#content_ar").val(response.data.content_ar);
                $("#content_en").val(response.data.content_en);
                $("#view_modal").modal("show");
              }
            }
      });
    });

    $(document.body).on('click', '.delete', function() {

      var notice_id = $(this).attr('table_id');
      //console.log(vaccination_id);
      Swal.fire({
        title: "<?php echo e(__('Are you sure?')); ?>",
        text: "<?php echo e(__('You will not be able to revert this!')); ?>",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: "<?php echo e(__('Delete')); ?>",
        cancelButtonText: "<?php echo e(__('Cancel')); ?>"
      }).then((result) => {
        if (result.isConfirmed) {

          $.ajax({
            url: '<?php echo e(url('notice/delete')); ?>',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:'POST',
            data:{
              notice_id : notice_id,
            },
            dataType : 'JSON',
            success:function(response){
                if(response.status==1){

                  Swal.fire(
                    "<?php echo e(__('Success')); ?>",
                    "<?php echo e(__('success')); ?>",
                    'success'
                  ).then((result)=>{
                    location.reload();
                  });
                }
              }
          });


        }
      })
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\njeek\resources\views/content/notices/list.blade.php ENDPATH**/ ?>